Tela de Login 

![image](https://github.com/FelipeValeriano21/Autorating-Mobile/assets/101677047/5d1c01f7-e529-4281-b714-53dc8e645803)


Recuperção de Senha 

![image](https://github.com/FelipeValeriano21/Autorating-Mobile/assets/101677047/b561f894-0374-481c-b307-0a9f19441724)

Recomendações da IA 

![image](https://github.com/FelipeValeriano21/Autorating-Mobile/assets/101677047/ae16907d-bd98-47e7-aa5a-b136c07f769d)
